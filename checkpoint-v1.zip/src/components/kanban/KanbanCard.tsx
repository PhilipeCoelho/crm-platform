import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { Deal } from "@/types/schema";
import { Building, User } from "lucide-react";

import { Currency } from "@/data/currencies";
import { useCRM } from "@/contexts/CRMContext";
import { useNavigate } from "react-router-dom";
import { format } from "date-fns";

interface Props {
    deal: Deal;
    currency: Currency;
    onPreview?: (dealId: string, position: { x: number; y: number }) => void;
}

function DealCard({ deal, currency, onPreview }: Props) {
    const { companies, contacts } = useCRM();
    const navigate = useNavigate();

    const {
        setNodeRef,
        attributes,
        listeners,
        transform,
        transition,
        isDragging,
    } = useSortable({
        id: deal.id,
        data: {
            type: "Deal",
            deal,
        },
    });

    const style = {
        transition,
        transform: CSS.Transform.toString(transform),
    };

    // Resolve Relations
    const company = deal.companyId ? companies.find(c => c.id === deal.companyId) : undefined;
    const contact = deal.contactId ? contacts.find(c => c.id === deal.contactId) : undefined;

    const handleClick = (e: React.MouseEvent) => {
        // Prevent navigation if clicking on action button or if dragging (handled by sensors usually)
        if (onPreview) {
            const rect = e.currentTarget.getBoundingClientRect();
            const x = rect.left + rect.width / 2; // Center X
            const y = rect.top + rect.height / 2; // Center Y
            onPreview(deal.id, { x, y });
        } else {
            navigate(`/deals/${deal.id}`);
        }
    };

    if (isDragging) {
        return (
            <div
                ref={setNodeRef}
                style={style}
                className="bg-background p-3 rounded-lg border-2 border-primary opacity-30 h-[100px]"
            />
        );
    }

    return (
        <div
            ref={setNodeRef}
            style={style}
            {...attributes}
            {...listeners}
            onClick={handleClick}
            className="group relative bg-white p-3 rounded-md border border-gray-200 shadow-[0_1px_2px_rgba(0,0,0,0.05)] hover:shadow-md hover:border-primary/50 transition-all cursor-pointer touch-none select-none"
        >
            {/* Title */}
            <div className="mb-1 pr-4"> {/* Padding right for potential absolute items */}
                <h4 className="font-semibold text-[14px] text-[#191919] leading-snug group-hover:text-primary transition-colors line-clamp-2">
                    {deal.title}
                </h4>
            </div>

            {/* Company / Contact Subtitle */}
            <div className="flex flex-col gap-0.5 mb-3">
                {company && (
                    <div className="flex items-center gap-1.5 text-gray-500" title={company.name}>
                        <Building size={12} className="shrink-0" />
                        <span className="text-[12px] truncate">{company.name}</span>
                    </div>
                )}
                {!company && contact && (
                    <div className="flex items-center gap-1.5 text-gray-500" title={contact.name}>
                        <User size={12} className="shrink-0" />
                        <span className="text-[12px] truncate">{contact.name}</span>
                    </div>
                )}
            </div>

            {/* Footer: Avatar + Value + Indicators */}
            <div className="flex items-center justify-between pt-2 border-t border-gray-50 mt-1">
                <div className="flex items-center gap-2">
                    {/* Contact Avatar (Initials) */}
                    <div className="w-5 h-5 rounded-full bg-gray-100 border border-gray-200 flex items-center justify-center text-[10px] font-bold text-gray-600" title={contact?.name || 'Sem contato'}>
                        {contact?.name?.substring(0, 1).toUpperCase() || '?'}
                    </div>
                    {(deal.contactId && !contact) && <span className="text-[10px] text-red-400">?</span>}
                </div>

                <div className="flex items-center gap-2">
                    <span className="text-[13px] font-bold text-[#191919]">
                        {new Intl.NumberFormat(currency.locale, { style: 'currency', currency: currency.code }).format(deal.value)}
                    </span>

                    {/* Activity Indicator */}
                    <ActivityIndicator dealId={deal.id} />
                </div>
            </div>

            {/* Priority Indicator Dot (Absolute Top Right) */}
            {deal.priority === 'high' && (
                <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-500 ring-1 ring-white" title="Alta Prioridade" />
            )}
        </div>
    );
}

function ActivityIndicator({ dealId }: { dealId: string }) {
    const { activities } = useCRM();

    // Logic:
    // Green: Open activity due Today or Overdue
    // Grey: Open activity due Future
    // Yellow: No open activity

    // 1. Get open activities for this deal
    const openActivities = activities.filter(a => a.dealId === dealId && !a.completed);

    if (openActivities.length === 0) {
        return <div className="w-3 h-3 rounded-full bg-yellow-400 border border-yellow-500 shadow-sm" title="Sem atividades agendadas" />;
    }

    // 2. Check for "Today or Overdue" using local date
    const todayStr = format(new Date(), 'yyyy-MM-dd');

    const hasTodayOrOverdue = openActivities.some(a => {
        if (!a.dueDate) return false;
        return a.dueDate <= todayStr || a.dueDate.startsWith(todayStr);
    });

    if (hasTodayOrOverdue) {
        return <div className="w-3 h-3 rounded-full bg-green-500 border border-green-600 shadow-sm" title="Atividade para hoje" />;
    }

    // Otherwise it must be future
    return <div className="w-3 h-3 rounded-full bg-gray-400 border border-gray-500 shadow-sm" title="Atividade futura" />;
}

export default DealCard;
