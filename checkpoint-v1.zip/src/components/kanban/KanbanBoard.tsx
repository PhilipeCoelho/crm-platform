import { useState } from "react";
import { useCRM } from "@/contexts/CRMContext";
import { Deal } from "@/types/schema";
import KanbanColumn from "./KanbanColumn";
import {
    DndContext,
    DragOverEvent,
    DragOverlay,
    DragStartEvent,
    PointerSensor,
    useSensor,
    useSensors,
} from "@dnd-kit/core";
import { SortableContext } from "@dnd-kit/sortable";
import { createPortal } from "react-dom";
import DealCard from "./KanbanCard";
import NewDealModal from "./NewDealModal";
import { Filter, Search, DollarSign, Plus } from "lucide-react";
import { Currency } from "@/data/currencies";
import DealPreviewPopover from "./DealPreviewPopover";

interface KanbanBoardProps {
    currency: Currency;
}

function KanbanBoard({ currency }: KanbanBoardProps) {
    const { deals, pipelines, updateDeal } = useCRM();
    // Default to 'sales' pipeline for now, can be dynamic
    const [currentPipelineId] = useState('sales');

    const currentPipeline = pipelines[currentPipelineId];
    // Helper to get columns (stages)
    const columns = currentPipeline?.stages || [];
    const columnsId = columns.map(col => col.id);

    // --- Filters State ---
    const [searchTerm, setSearchTerm] = useState('');
    const [showFilters, setShowFilters] = useState(false);
    const [minValue, setMinValue] = useState<string>('');

    // Filter deals for current pipeline
    const pipelineDeals = deals.filter(deal => deal.pipelineId === currentPipelineId);

    // --- Filter Logic ---
    const filteredDeals = pipelineDeals.filter(deal => {
        const matchesSearch = deal.title.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesValue = minValue ? deal.value >= Number(minValue) : true;
        const isOpen = deal.status === 'open'; // Only show open deals
        return matchesSearch && matchesValue && isOpen;
    });

    const [activeColumnId, setActiveColumnId] = useState<string | null>(null);
    const [activeDeal, setActiveDeal] = useState<Deal | null>(null);

    // New Deal Modal State
    const [isNewDealModalOpen, setIsNewDealModalOpen] = useState(false);
    const [newDealStageId, setNewDealStageId] = useState<string | null>(null);

    // Deal Preview State
    const [previewDealId, setPreviewDealId] = useState<string | null>(null);
    const [previewPosition, setPreviewPosition] = useState<{ x: number; y: number } | null>(null);

    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: {
                distance: 10,
            },
        })
    );

    const openNewDealModal = (stageId: string) => {
        setNewDealStageId(stageId);
        setIsNewDealModalOpen(true);
    };

    const handlePreview = (dealId: string, position: { x: number; y: number }) => {
        setPreviewDealId(dealId);
        setPreviewPosition(position);
    };

    const activeColumn = columns.find(c => c.id === activeColumnId);

    return (
        <div className="flex flex-col h-full w-full bg-white overflow-hidden">
            {/* Single Line Toolbar (Pipedrive Style) */}
            <div className="h-14 border-b border-border flex items-center justify-between px-4 bg-white shrink-0 gap-4 z-40">
                {/* Left: Pipeline Title/Selector */}
                <div className="flex items-center gap-2">
                    <h1 className="text-lg font-bold text-[#191919] flex items-center gap-2 cursor-pointer hover:bg-gray-100 px-2 py-1 rounded-md transition-colors">
                        {currentPipeline?.name}
                        {/* <ChevronDown size={16} className="text-gray-500" /> */}
                    </h1>
                </div>

                {/* Right: Controls */}
                <div className="flex items-center gap-2 flex-1 justify-end">
                    {/* Search Inline */}
                    <div className="relative group w-64 transition-all focus-within:w-80">
                        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-primary" />
                        <input
                            type="text"
                            placeholder="Buscar..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="h-9 w-full pl-9 pr-4 rounded-md bg-[#f5f6f8] border border-transparent focus:bg-white focus:border-primary/30 focus:ring-2 focus:ring-primary/20 focus:outline-none text-sm transition-all placeholder:text-gray-400"
                        />
                    </div>

                    <div className="h-6 w-px bg-gray-200 mx-2" />

                    {/* Filter Toggle (with indicator if active) */}
                    <div className="relative">
                        <button
                            onClick={() => setShowFilters(!showFilters)}
                            className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${showFilters || minValue ? 'bg-primary/10 text-primary' : 'hover:bg-gray-100 text-gray-700'}`}
                        >
                            <Filter size={16} />
                            <span>Filtros</span>
                        </button>

                        {/* Absolute Filter Popover */}
                        {showFilters && (
                            <div className="absolute right-0 top-full mt-2 w-72 bg-white border border-border shadow-lg rounded-lg p-4 z-50 animate-in fade-in zoom-in-95">
                                <div className="space-y-3">
                                    <div className="flex flex-col gap-1">
                                        <label className="text-xs font-semibold text-gray-500 uppercase">Valor Mínimo</label>
                                        <div className="relative">
                                            <DollarSign size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
                                            <input
                                                type="number"
                                                value={minValue}
                                                onChange={(e) => setMinValue(e.target.value)}
                                                className="w-full pl-8 pr-3 py-1.5 text-sm border border-gray-200 rounded-md focus:ring-2 focus:ring-primary/50 outline-none"
                                                placeholder="0.00"
                                            />
                                        </div>
                                    </div>
                                    <div className="flex justify-end pt-2 border-t border-gray-100">
                                        <button
                                            onClick={() => { setMinValue(''); setShowFilters(false); }}
                                            className="text-xs text-red-600 hover:text-red-700 font-medium"
                                        >
                                            Limpar e Fechar
                                        </button>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Add Deal Button (Primary Action) */}
                    <button
                        onClick={() => openNewDealModal(columns[0]?.id)}
                        className="ml-2 bg-[#00875A] hover:bg-[#00704a] text-white px-3 py-1.5 rounded-md text-sm font-bold flex items-center gap-1 shadow-sm transition-all"
                    >
                        {/* Green Pipedrive color approx */}
                        <Plus size={16} />
                        <span>Novo Negócio</span>
                    </button>
                </div>
            </div>

            {/* Kanban Content */}
            <div className="flex-1 p-0 w-full h-full overflow-hidden bg-white">
                <DndContext
                    sensors={sensors}
                    onDragStart={onDragStart}
                    onDragEnd={onDragEnd}
                    onDragOver={onDragOver}
                >
                    <div className="flex h-full w-full overflow-x-auto overflow-y-hidden pb-2 px-2 pt-2 gap-2"> {/* Dense Gap and Padding */}
                        <SortableContext items={columnsId}>
                            {columns.map((col) => (
                                <KanbanColumn
                                    key={col.id}
                                    column={col} // Adapting Stage to Column interface visually
                                    tasks={filteredDeals.filter(d => d.stageId === col.id) as any} // Cast Deal to Task temporarily or update Column
                                    updateColumn={() => { }} // Read-only cols for now
                                    onAdd={openNewDealModal}
                                    currency={currency}
                                    onPreview={handlePreview}
                                />
                            ))}
                        </SortableContext>
                    </div>

                    {createPortal(
                        <DragOverlay>
                            {activeColumn && (
                                <KanbanColumn
                                    column={activeColumn!}
                                    tasks={filteredDeals.filter(d => d.stageId === activeColumn.id) as any}
                                    updateColumn={() => { }}
                                    onAdd={() => { }}
                                    currency={currency}
                                />
                            )}
                            {activeDeal && <DealCard deal={activeDeal!} currency={currency} />}
                        </DragOverlay>,
                        document.body
                    )}
                </DndContext>

                <NewDealModal
                    isOpen={isNewDealModalOpen}
                    onClose={() => setIsNewDealModalOpen(false)}
                    initialColumnId={newDealStageId || undefined}
                    currency={currency.code}
                />

                {/* Deal Preview Popover */}
                {previewDealId && (
                    <DealPreviewPopover
                        dealId={previewDealId!}
                        position={previewPosition!}
                        onClose={() => setPreviewDealId(null)}
                    />
                )}
            </div>
        </div>
    );

    function onDragStart(event: DragStartEvent) {
        if (event.active.data.current?.type === "Column") {
            setActiveColumnId(event.active.id as string);
            return;
        }

        if (event.active.data.current?.type === "Deal") {
            setActiveDeal(event.active.data.current.deal);
            return;
        }
    }

    function onDragEnd() {
        setActiveColumnId(null);
        setActiveDeal(null);
    }

    function onDragOver(event: DragOverEvent) {
        const { active, over } = event;
        if (!over) return;

        const activeId = active.id;
        const overId = over.id;

        if (activeId === overId) return;

        const isActiveDeal = active.data.current?.type === "Deal";
        const isOverColumn = over.data.current?.type === "Column";

        if (!isActiveDeal) return;

        // Dropping over a column
        if (isOverColumn) {
            const deal = deals.find(d => d.id === activeId);
            if (deal && deal.stageId !== overId) {
                updateDeal(deal.id, { stageId: overId as string });
            }
        }

        const overDeal = deals.find(d => d.id === overId);
        if (overDeal && active.data.current?.deal) {
            const activeDeal = active.data.current.deal;
            if (activeDeal.stageId !== overDeal.stageId) {
                updateDeal(activeDeal.id, { stageId: overDeal.stageId });
            }
        }
    }
}

export default KanbanBoard;
