import { useState } from 'react';
import { useCRM } from '@/contexts/CRMContext';
import { Deal } from '@/types/schema';
import { Calendar, Clock, CheckCircle2 } from 'lucide-react';

interface ActivityTabProps {
    deal: Deal;
    onSave?: () => void;
}

export default function ActivityTab({ deal, onSave }: ActivityTabProps) {
    const { addActivity } = useCRM();
    const [title, setTitle] = useState('');
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [time, setTime] = useState('10:00');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!title.trim()) return;

        addActivity({
            type: 'task',
            title,
            dealId: deal.id,
            dueDate: `${date}T${time}:00.000Z`,
            completed: false
        });
        setTitle('');
        if (onSave) onSave();
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 p-4 border rounded-lg bg-card/50">
            <input
                type="text"
                placeholder="O que você precisa fazer?"
                className="w-full p-2 bg-transparent border-b border-border focus:border-primary outline-none font-medium"
                value={title}
                onChange={e => setTitle(e.target.value)}
                autoFocus
            />

            <div className="flex gap-4">
                <div className="flex-1 flex items-center gap-2 border rounded-md p-2 bg-background">
                    <Calendar size={16} className="text-muted-foreground" />
                    <input
                        type="date"
                        className="bg-transparent outline-none flex-1 text-sm"
                        value={date}
                        onChange={e => setDate(e.target.value)}
                    />
                </div>
                <div className="flex-1 flex items-center gap-2 border rounded-md p-2 bg-background">
                    <Clock size={16} className="text-muted-foreground" />
                    <input
                        type="time"
                        className="bg-transparent outline-none flex-1 text-sm"
                        value={time}
                        onChange={e => setTime(e.target.value)}
                    />
                </div>
            </div>

            <div className="flex justify-end">
                <button
                    type="submit"
                    disabled={!title.trim()}
                    className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 font-medium text-sm flex items-center gap-2"
                >
                    <CheckCircle2 size={16} />
                    Salvar Tarefa
                </button>
            </div>
        </form>
    );
}
