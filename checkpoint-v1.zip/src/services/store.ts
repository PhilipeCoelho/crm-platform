import { useState, useEffect, useCallback } from 'react';
import {
    User, Company, Contact, Deal, Activity, Pipeline, Stage,
    DEFAULT_PIPELINES
} from '../types/schema';
import { supabase } from './supabase';


// --- Types ---
export interface CRMStore {
    users: User[]; // Kept for type compatibility, though managed by Auth now
    companies: Company[];
    contacts: Contact[];
    deals: Deal[];
    activities: Activity[];
    pipelines: Record<string, Pipeline>;

    // Actions
    addDeal: (deal: Omit<Deal, 'id' | 'createdAt' | 'updatedAt' | 'userId'>) => Promise<void>;
    updateDeal: (id: string, updates: Partial<Deal>) => Promise<void>;
    deleteDeal: (id: string) => Promise<void>;

    addCompany: (company: Omit<Company, 'id' | 'createdAt'>) => Promise<Company>;
    updateCompany: (id: string, updates: Partial<Company>) => Promise<void>;

    addContact: (contact: Omit<Contact, 'id' | 'createdAt' | 'userId'>) => Promise<Contact>;
    updateContact: (id: string, updates: Partial<Contact>) => Promise<void>;
    deleteContact: (id: string) => Promise<void>;

    addActivity: (activity: Omit<Activity, 'id' | 'createdAt' | 'userId'>) => Promise<void>;
    updateActivity: (id: string, updates: Partial<Activity>) => Promise<void>;
    deleteActivity: (id: string) => Promise<void>;

    // Helpers
    getPipelineStages: (pipelineId: string) => Stage[];
    refresh: () => Promise<void>;
}

// --- Helpers ---
const generateId = () => crypto.randomUUID(); // Use native UUID if possible, or fallback

export function useCRMStore(): CRMStore {
    const [deals, setDeals] = useState<Deal[]>([]);
    const [contacts, setContacts] = useState<Contact[]>([]);
    const [activities, setActivities] = useState<Activity[]>([]);
    const [companies] = useState<Company[]>([]); // Note: Companies table not in SQL yet, keeping local/mock for now or mapping to contacts? 
    // *Correction*: User schema didn't fully specifying Company table. 
    // We will handle Companies as local-only for now OR map to a simple jsonb if needed. 
    // For this migration, let's keep companies in memory/local storage or create a table if requested. 
    // Given the prompt, we focus on Deals/Activities/Profiles. Contacts table exists.
    // Let's create a local mock for companies to avoid breaking UI, or sync if table existed.

    const [pipelines] = useState<Record<string, Pipeline>>(DEFAULT_PIPELINES);

    // --- Data Fetching ---
    const fetchAll = useCallback(async () => {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        // Fetch Deals
        const { data: dealsData } = await supabase.from('deals').select('*').order('created_at', { ascending: false });
        if (dealsData) {
            // Map SQL columns to Frontend types if needed (snake_case to camelCase)
            // Our SQL uses same names mostly, but let's ensure mapping
            const mappedDeals: Deal[] = dealsData.map(d => ({
                ...d,
                columnId: d.stage_id, // Map stage_id back to UI's expected 'columnId' or 'stageId'
                stageId: d.stage_id,
                contactId: d.contact_id,
                userId: d.user_id,
                createdAt: d.created_at,
                updatedAt: d.created_at, // SQL doesn't have updated_at yet, use created_at
                pipelineId: 'sales', // Default
                currency: 'BRL', // Default
                status: d.status || 'open',
                value: Number(d.value)
            }));
            setDeals(mappedDeals);
        }

        // Fetch Contacts
        const { data: contactsData } = await supabase.from('contacts').select('*');
        if (contactsData) {
            setContacts(contactsData.map(c => ({
                ...c,
                userId: c.user_id,
                companyId: '1', // Placeholder
                createdAt: c.created_at
            })));
        }

        // Fetch Activities
        const { data: activitiesData } = await supabase.from('activities').select('*');
        if (activitiesData) {
            setActivities(activitiesData.map(a => ({
                ...a,
                dealId: a.deal_id,
                userId: a.user_id,
                createdAt: a.created_at
            })));
        }

    }, []);

    // --- Initial Load & Realtime ---
    useEffect(() => {
        // Initial fetch
        fetchAll();

        // Listen for Auth Changes (Sign In, etc.) to trigger fetch
        const { data: { subscription: authListener } } = supabase.auth.onAuthStateChange((event, session) => {
            if (event === 'SIGNED_IN' && session) {
                console.log('🔐 Auth changed: SIGNED_IN. Refetching data...');
                fetchAll();
            }
        });

        // Listen for DB Changes
        const channel = supabase.channel('crm_realtime')
            .on('postgres_changes', { event: '*', schema: 'public' }, () => {
                console.log('⚡ Realtime update detected. Refetching...');
                fetchAll();
            })
            .subscribe();

        return () => {
            authListener.unsubscribe();
            supabase.removeChannel(channel);
        };
    }, [fetchAll]);


    // --- Actions (Optimistic + Async) ---

    const addDeal = async (data: Omit<Deal, 'id' | 'createdAt' | 'updatedAt' | 'userId'>) => {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
            alert('Erro: Usuário não autenticado. Tente fazer login novamente.');
            return;
        }

        const newDeal = {
            title: data.title,
            value: data.value,
            contact_id: data.contactId,
            user_id: user.id,
            stage_id: data.stageId,
            status: 'open'
        };

        // Optimistic
        const tempId = generateId();
        const optimisticDeal: Deal = {
            ...data,
            id: tempId,
            userId: user.id,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        } as Deal;
        setDeals(prev => [optimisticDeal, ...prev]);

        // DB
        const { error } = await supabase.from('deals').insert(newDeal);
        if (error) {
            console.error('Error adding deal:', error);
            alert(`Erro ao salvar negócio: ${error.message}`);
            // Revert optimistic update
            setDeals(prev => prev.filter(d => d.id !== tempId));
        }
    };

    const updateDeal = async (id: string, updates: Partial<Deal>) => {
        // Optimistic
        setDeals(prev => prev.map(d => d.id === id ? { ...d, ...updates } : d));

        // DB Map
        const dbUpdates: any = {};
        if (updates.title) dbUpdates.title = updates.title;
        if (updates.value) dbUpdates.value = updates.value;
        if (updates.stageId) dbUpdates.stage_id = updates.stageId;
        if (updates.status) dbUpdates.status = updates.status;

        if (Object.keys(dbUpdates).length > 0) {
            const { error } = await supabase.from('deals').update(dbUpdates).eq('id', id);
            if (error) console.error('Update deal error', error);
        }
    };

    const deleteDeal = async (id: string) => {
        setDeals(prev => prev.filter(d => d.id !== id));
        await supabase.from('deals').delete().eq('id', id);
    };

    const addContact = async (data: Omit<Contact, 'id' | 'createdAt' | 'userId'>) => {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error("No user");

        const newContact = {
            name: data.name,
            email: data.email,
            phone: data.phone,
            role: data.role,
            user_id: user.id
        };

        // Optimistic
        const tempId = generateId();
        const optimisticContact = { ...data, id: tempId, userId: user.id, createdAt: new Date().toISOString() } as Contact;
        setContacts(prev => [...prev, optimisticContact]);

        const { data: inserted, error } = await supabase.from('contacts').insert(newContact).select().single();
        if (error) {
            setContacts(prev => prev.filter(c => c.id !== tempId));
            throw error;
        }
        return { ...optimisticContact, id: inserted.id };
    };

    const updateContact = async (id: string, updates: Partial<Contact>) => {
        setContacts(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
        await supabase.from('contacts').update(updates).eq('id', id);
    };

    const deleteContact = async (id: string) => {
        // Optimistic update
        setContacts(prev => prev.filter(c => c.id !== id));
        setDeals(prev => prev.map(d => d.contactId === id ? { ...d, contactId: undefined } : d));

        // 1. Unlink Deals first (to satisfy Foreign Key constraints)
        const { error: unlinkError } = await supabase
            .from('deals')
            .update({ contact_id: null })
            .eq('contact_id', id);

        if (unlinkError) {
            console.error('Error unlinking deals:', unlinkError);
            alert(`Erro ao desvincular negócios associados: ${unlinkError.message}`);
            fetchAll();
            return;
        }

        // 2. Delete Contact
        const { error } = await supabase.from('contacts').delete().eq('id', id);
        if (error) {
            console.error('Error deleting contact:', error);
            alert(`Erro ao excluir contato: ${error.message}`);
            fetchAll(); // Restore
        }
    };

    // Stub implementations for others to match interface
    const addActivity = async (data: any) => {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        const newActivity = {
            title: data.title,
            type: data.type,
            date: data.date,
            duration: data.duration,
            deal_id: data.dealId,
            user_id: user.id
        };

        setActivities(prev => [...prev, { ...data, id: generateId(), userId: user.id, createdAt: new Date().toISOString() }]);

        await supabase.from('activities').insert(newActivity);
    };

    const updateActivity = async (id: string, updates: Partial<Activity>) => {
        setActivities(prev => prev.map(a => a.id === id ? { ...a, ...updates } : a));
        // DB update logic could go here
    };

    const deleteActivity = async (id: string) => {
        setActivities(prev => prev.filter(a => a.id !== id));
        await supabase.from('activities').delete().eq('id', id);
    };

    const addCompany = async (data: any) => { return data as Company }; // Mock
    const updateCompany = async () => { };

    return {
        users: [],
        companies,
        contacts,
        deals,
        activities,
        pipelines,
        addDeal, updateDeal, deleteDeal,
        addContact, updateContact, deleteContact,
        addActivity, updateActivity, deleteActivity,
        addCompany, updateCompany,
        getPipelineStages: (pid) => pipelines[pid]?.stages || [],
        refresh: fetchAll
    };
}
