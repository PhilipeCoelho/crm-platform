import React, { useState } from 'react';
import { CRMProvider } from './contexts/CRMContext';
import { BrowserRouter, Routes, Route, Navigate, useLocation, Link } from 'react-router-dom';
import { LayoutDashboard, Users, CheckSquare, Settings, LogOut, ChevronRight, CheckSquare as CheckIcon, Loader2 } from 'lucide-react';
import KanbanBoard from '@/components/kanban/KanbanBoard';
import ContactList from '@/components/contacts/ContactList';
import Login from '@/pages/Login';
import { currencies, Currency } from '@/data/currencies';
import DealDetails from '@/pages/DealDetails';
import CompanyDetails from '@/pages/CompanyDetails';
import ContactDetails from '@/pages/ContactDetails';
import Dashboard from '@/pages/Dashboard';
import { useSupabaseAuth } from '@/hooks/useSupabaseAuth';

function Layout({ children }: { children: React.ReactNode }) {
    const { user, signOut } = useSupabaseAuth();
    const location = useLocation();

    const currentView = location.pathname.includes('contacts') ? 'contacts' :
        location.pathname.includes('activities') ? 'activities' :
            location.pathname.includes('dashboard') ? 'dashboard' : 'pipelines';

    const [isSettingsOpen, setIsSettingsOpen] = React.useState(false);
    const [isCurrencySubmenuOpen, setIsCurrencySubmenuOpen] = React.useState(false);
    const [selectedCurrency, setSelectedCurrency] = React.useState<Currency>(currencies[0]);
    const [isSidebarExpanded, setIsSidebarExpanded] = useState(false);

    if (!user) return null;

    return (
        <div className="flex h-screen bg-background text-foreground overflow-hidden">
            {/* Expandable Sidebar */}
            <aside
                className={`bg-[#1a1d21] text-[#9ca6af] flex flex-col items-center py-3 z-50 shrink-0 border-r border-border/10 transition-all duration-300 ease-in-out ${isSidebarExpanded ? 'w-56 items-start px-3' : 'w-14 items-center'}`}
                onMouseEnter={() => setIsSidebarExpanded(true)}
                onMouseLeave={() => setIsSidebarExpanded(false)}
            >
                {/* App Logo / Brand */}
                <div className={`mb-6 h-8 flex items-center transition-all duration-300 ${isSidebarExpanded ? 'w-full px-2 gap-3' : 'w-8 justify-center'}`}>
                    <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center text-primary-foreground font-bold text-xs shrink-0 select-none">
                        CP
                    </div>
                    <span className={`font-bold text-white whitespace-nowrap overflow-hidden transition-all duration-300 ${isSidebarExpanded ? 'opacity-100 w-auto' : 'opacity-0 w-0'}`}>
                        CRM Pro
                    </span>
                </div>

                <nav className="flex-1 flex flex-col w-full space-y-2">
                    <Link to="/pipeline" title={!isSidebarExpanded ? "Pipeline" : ""}
                        className={`group flex items-center gap-3 rounded-lg transition-all duration-200 min-h-[40px] ${isSidebarExpanded ? 'px-3 w-full justify-start' : 'justify-center w-10 mx-auto'} ${currentView === 'pipelines' ? 'bg-[#26292c] text-white shadow-sm' : 'hover:bg-[#26292c] hover:text-white'}`}
                    >
                        <div className="shrink-0 flex items-center justify-center w-5 h-5">
                            <CheckSquare strokeWidth={currentView === 'pipelines' ? 2.5 : 2} size={20} />
                        </div>
                        <span className={`whitespace-nowrap overflow-hidden transition-all duration-300 ${isSidebarExpanded ? 'opacity-100 w-auto delay-75' : 'opacity-0 w-0'}`}>Pipeline</span>
                    </Link>

                    <Link to="/contacts" title={!isSidebarExpanded ? "Contatos" : ""}
                        className={`group flex items-center gap-3 rounded-lg transition-all duration-200 min-h-[40px] ${isSidebarExpanded ? 'px-3 w-full justify-start' : 'justify-center w-10 mx-auto'} ${currentView === 'contacts' ? 'bg-[#26292c] text-white shadow-sm' : 'hover:bg-[#26292c] hover:text-white'}`}
                    >
                        <div className="shrink-0 flex items-center justify-center w-5 h-5">
                            <Users strokeWidth={currentView === 'contacts' ? 2.5 : 2} size={20} />
                        </div>
                        <span className={`whitespace-nowrap overflow-hidden transition-all duration-300 ${isSidebarExpanded ? 'opacity-100 w-auto delay-75' : 'opacity-0 w-0'}`}>Contatos</span>
                    </Link>

                    <Link to="/dashboard" title={!isSidebarExpanded ? "Dashboard" : ""}
                        className={`group flex items-center gap-3 rounded-lg transition-all duration-200 min-h-[40px] ${isSidebarExpanded ? 'px-3 w-full justify-start' : 'justify-center w-10 mx-auto'} ${currentView === 'dashboard' ? 'bg-[#26292c] text-white shadow-sm' : 'hover:bg-[#26292c] hover:text-white'}`}
                    >
                        <div className="shrink-0 flex items-center justify-center w-5 h-5">
                            <LayoutDashboard strokeWidth={currentView === 'dashboard' ? 2.5 : 2} size={20} />
                        </div>
                        <span className={`whitespace-nowrap overflow-hidden transition-all duration-300 ${isSidebarExpanded ? 'opacity-100 w-auto delay-75' : 'opacity-0 w-0'}`}>Dashboard</span>
                    </Link>
                </nav>

                <div className={`flex flex-col w-full space-y-2 mt-auto pb-2 ${isSidebarExpanded ? 'items-start' : 'items-center'}`}>
                    <button
                        onClick={() => setIsSettingsOpen(!isSettingsOpen)}
                        title={!isSidebarExpanded ? "Configurações" : ""}
                        className={`group flex items-center gap-3 rounded-lg transition-all duration-200 min-h-[40px] ${isSidebarExpanded ? 'px-3 w-full justify-start' : 'justify-center w-10 mx-auto'} ${isSettingsOpen ? 'bg-[#26292c] text-white' : 'hover:bg-[#26292c] hover:text-white'}`}
                    >
                        <div className="shrink-0 flex items-center justify-center w-5 h-5">
                            <Settings size={20} />
                        </div>
                        <span className={`whitespace-nowrap overflow-hidden transition-all duration-300 ${isSidebarExpanded ? 'opacity-100 w-auto delay-75' : 'opacity-0 w-0'}`}>Configurações</span>
                    </button>

                    <button
                        onClick={() => signOut()}
                        title={!isSidebarExpanded ? "Sair" : ""}
                        className={`group flex items-center gap-3 rounded-lg hover:bg-red-900/20 hover:text-red-400 transition-all duration-200 min-h-[40px] ${isSidebarExpanded ? 'px-3 w-full justify-start' : 'justify-center w-10 mx-auto'}`}
                    >
                        <div className="shrink-0 flex items-center justify-center w-5 h-5">
                            <LogOut size={20} />
                        </div>
                        <span className={`whitespace-nowrap overflow-hidden transition-all duration-300 ${isSidebarExpanded ? 'opacity-100 w-auto delay-75' : 'opacity-0 w-0'}`}>Sair</span>
                    </button>

                    {/* User Avatar (Mini) */}
                    <div className={`flex items-center gap-3 mt-2 rounded-md border border-border/10 p-1 bg-white/5 ${isSidebarExpanded ? 'w-full px-2' : 'w-8 justify-center border-none bg-transparent'}`}>
                        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-[10px] font-bold text-primary shrink-0">
                            {user.email?.substring(0, 1).toUpperCase() || 'U'}
                        </div>
                        <div className={`flex flex-col overflow-hidden transition-all duration-300 ${isSidebarExpanded ? 'opacity-100 w-auto' : 'opacity-0 w-0 hidden'}`}>
                            <span className="text-xs font-medium text-white truncate" title={user.email}>{user.email}</span>
                            <span className="text-[10px] text-gray-500">Usuário</span>
                        </div>
                    </div>
                </div>

                {/* Settings Popover (Adjusted position) */}
                {isSettingsOpen && (
                    <div className={`fixed bottom-16 w-64 bg-popover border border-border rounded-lg shadow-xl z-[60] animate-in fade-in zoom-in-95 duration-200 ${isSidebarExpanded ? 'left-60' : 'left-16 ml-2'}`}>
                        <div className="p-3 border-b border-border">
                            <h3 className="font-medium text-sm">Configurações</h3>
                        </div>
                        <div className="p-2">
                            <button onClick={() => setIsCurrencySubmenuOpen(!isCurrencySubmenuOpen)} className="w-full flex items-center justify-between px-2 py-2 text-sm font-medium hover:bg-muted rounded-md transition-colors">
                                <span className="flex items-center gap-2"><div className="w-1 h-4 bg-primary/50 rounded-full"></div>Moedas</span>
                                <ChevronRight size={14} />
                            </button>
                            {isCurrencySubmenuOpen && (
                                <div className="mt-1 pl-2 space-y-0.5">
                                    {currencies.map(c => (
                                        <button key={c.code} onClick={() => { setSelectedCurrency(c); setIsSettingsOpen(false); }} className="w-full text-left px-3 py-1.5 hover:bg-muted rounded-md text-xs flex items-center justify-between text-muted-foreground hover:text-foreground"
                                        >
                                            <span>{c.name} ({c.symbol})</span>
                                            {selectedCurrency.code === c.code && <CheckIcon size={12} className="text-primary" />}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>
                        <div className="fixed inset-0 z-[-1]" onClick={() => setIsSettingsOpen(false)} />
                    </div>
                )}
            </aside>

            {/* Main Content Area */}
            <main className="flex-1 flex flex-col h-screen overflow-hidden bg-background relative">
                {/* No Global Header - Views define their own toolbars */}
                <div className="flex-1 overflow-hidden">
                    <div className="h-full w-full max-w-[1700px] mx-auto flex flex-col">
                        {children}
                    </div>
                </div>
            </main>
        </div>
    );
}

function App() {
    const { user, loading } = useSupabaseAuth();
    const [selectedCurrency] = useState<Currency>(currencies[0]);

    if (loading) {
        return (
            <div className="h-screen w-screen flex items-center justify-center bg-background">
                <Loader2 className="w-8 h-8 text-primary animate-spin" />
            </div>
        );
    }

    if (!user) {
        // onLogin is handled by the auth state change in useSupabaseAuth, 
        // which triggers a re-render here with user present.
        return <Login onLogin={() => { }} />;
    }

    return (
        <CRMProvider>
            <BrowserRouter>
                <Layout>
                    <Routes>
                        <Route path="/" element={<Navigate to="/dashboard" replace />} />
                        <Route path="/dashboard" element={<Dashboard />} />
                        <Route path="/pipeline" element={
                            <div className="h-full w-full flex flex-col">
                                {/* KanbanBoard now handles its own full layout */}
                                <KanbanBoard currency={selectedCurrency} />
                            </div>
                        } />
                        <Route path="/contacts" element={<div className="p-4 h-full max-w-[1500px] mx-auto"><ContactList /></div>} />
                        <Route path="/deals/:id" element={<DealDetails />} />
                        <Route path="/companies/:id" element={<CompanyDetails />} />
                        <Route path="/contacts/:id" element={<ContactDetails />} />
                    </Routes>
                </Layout>
            </BrowserRouter>
        </CRMProvider>
    );
}

export default App;
