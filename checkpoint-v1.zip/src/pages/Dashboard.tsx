import { useCRM } from '@/contexts/CRMContext';
import { DollarSign, Trophy, TrendingUp, Activity as ActivityIcon, ArrowUpRight } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Dashboard() {
    const { deals, activities } = useCRM();

    // --- Metrics Calculations ---
    const openDeals = deals.filter(d => d.status === 'open');
    const wonDeals = deals.filter(d => d.status === 'won');
    const lostDeals = deals.filter(d => d.status === 'lost');

    const totalPipelineValue = openDeals.reduce((sum, deal) => sum + deal.value, 0);
    const totalWonValue = wonDeals.reduce((sum, deal) => sum + deal.value, 0);

    const totalClosed = wonDeals.length + lostDeals.length;
    const conversionRate = totalClosed > 0
        ? Math.round((wonDeals.length / totalClosed) * 100)
        : 0;

    const avgDealValue = wonDeals.length > 0
        ? Math.round(totalWonValue / wonDeals.length)
        : 0;

    // --- Recent Activities ---
    const recentActivities = [...activities]
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5);

    // --- Formatters ---
    const formatCurrency = (value: number) => {
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(value);
    };

    return (
        <div className="p-8 h-full overflow-y-auto bg-background/50">
            <div className="flex items-center justify-between mb-8">
                <div>
                    <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
                    <p className="text-muted-foreground mt-1">Visão geral do seu desempenho comercial.</p>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground bg-card px-3 py-1 rounded-full border border-border shadow-sm">
                    <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                    </span>
                    Atualizado agorinha
                </div>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">

                {/* Metric 1: Pipeline Value */}
                <div className="bg-card p-6 rounded-2xl border border-border/50 shadow-sm hover:shadow-md transition-all group">
                    <div className="flex items-center justify-between mb-4">
                        <div className="p-2 bg-primary/10 rounded-lg text-primary group-hover:scale-110 transition-transform">
                            <DollarSign size={22} />
                        </div>
                        <span className="text-xs font-medium text-muted-foreground bg-muted px-2 py-1 rounded">Em Aberto</span>
                    </div>
                    <div>
                        <p className="text-sm font-medium text-muted-foreground">Valor em Pipeline</p>
                        <h3 className="text-2xl font-bold mt-1 text-foreground">{formatCurrency(totalPipelineValue)}</h3>
                    </div>
                    <div className="mt-4 flex items-center gap-1 text-xs text-muted-foreground">
                        <span className="font-medium text-foreground">{openDeals.length}</span> negócios ativos
                    </div>
                </div>

                {/* Metric 2: Deals Won */}
                <div className="bg-card p-6 rounded-2xl border border-border/50 shadow-sm hover:shadow-md transition-all group">
                    <div className="flex items-center justify-between mb-4">
                        <div className="p-2 bg-green-500/10 rounded-lg text-green-500 group-hover:scale-110 transition-transform">
                            <Trophy size={22} />
                        </div>
                        <span className="text-xs font-medium text-muted-foreground bg-muted px-2 py-1 rounded">Total Ganho</span>
                    </div>
                    <div>
                        <p className="text-sm font-medium text-muted-foreground">Receita Gerada</p>
                        <h3 className="text-2xl font-bold mt-1 text-foreground">{formatCurrency(totalWonValue)}</h3>
                    </div>
                    <div className="mt-4 flex items-center gap-1 text-xs text-green-600 font-medium">
                        <ArrowUpRight size={14} />
                        {wonDeals.length} negócios fechados
                    </div>
                </div>

                {/* Metric 3: Conversion Rate */}
                <div className="bg-card p-6 rounded-2xl border border-border/50 shadow-sm hover:shadow-md transition-all group">
                    <div className="flex items-center justify-between mb-4">
                        <div className="p-2 bg-blue-500/10 rounded-lg text-blue-500 group-hover:scale-110 transition-transform">
                            <TrendingUp size={22} />
                        </div>
                    </div>
                    <div>
                        <p className="text-sm font-medium text-muted-foreground">Taxa de Conversão</p>
                        <h3 className="text-2xl font-bold mt-1 text-foreground">{conversionRate}%</h3>
                    </div>
                    <div className="mt-4 flex items-center gap-1 text-xs text-muted-foreground">
                        De {totalClosed} finalizados
                    </div>
                </div>

                {/* Metric 4: Avg Deal Size */}
                <div className="bg-card p-6 rounded-2xl border border-border/50 shadow-sm hover:shadow-md transition-all group">
                    <div className="flex items-center justify-between mb-4">
                        <div className="p-2 bg-purple-500/10 rounded-lg text-purple-500 group-hover:scale-110 transition-transform">
                            <ActivityIcon size={22} />
                        </div>
                    </div>
                    <div>
                        <p className="text-sm font-medium text-muted-foreground">Ticket Médio</p>
                        <h3 className="text-2xl font-bold mt-1 text-foreground">{formatCurrency(avgDealValue)}</h3>
                    </div>
                    <div className="mt-4 flex items-center gap-1 text-xs text-muted-foreground">
                        Por negócio ganho
                    </div>
                </div>
            </div>

            {/* Layout Split: Recent Activity & Coming Soon Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

                {/* Recent Activity Feed */}
                <div className="lg:col-span-2 bg-card rounded-2xl border border-border/50 shadow-sm p-6">
                    <h3 className="text-lg font-semibold mb-6 flex items-center gap-2">
                        <ActivityIcon size={18} className="text-primary" />
                        Atividades Recentes
                    </h3>

                    <div className="space-y-6">
                        {recentActivities.length === 0 ? (
                            <div className="text-center py-10 text-muted-foreground text-sm">
                                Nenhuma atividade registrada ainda.
                            </div>
                        ) : (
                            recentActivities.map(activity => (
                                <div key={activity.id} className="flex gap-4 relative">
                                    {/* Timeline connector */}
                                    <div className="absolute left-[19px] top-8 bottom-[-24px] w-px bg-border last:hidden"></div>

                                    <div className={`
                                        w-10 h-10 rounded-full flex items-center justify-center shrink-0 border-2 border-background z-10
                                        ${activity.completed ? 'bg-green-100 text-green-600' : 'bg-primary/10 text-primary'}
                                    `}>
                                        {activity.type === 'call' && '📞'}
                                        {activity.type === 'meeting' && '📅'}
                                        {activity.type === 'email' && '📧'}
                                        {activity.type === 'task' && '✅'}
                                        {activity.type === 'followup' && '👀'}
                                    </div>
                                    <div className="flex-1 pb-1">
                                        <div className="flex items-center justify-between">
                                            <h4 className="text-sm font-medium text-foreground">{activity.title}</h4>
                                            <span className="text-xs text-muted-foreground whitespace-nowrap">
                                                {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true, locale: ptBR })}
                                            </span>
                                        </div>
                                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1 opacity-80">
                                            {activity.description || 'Sem descrição adicional'}
                                        </p>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                </div>

                {/* Mini Goal / Forecast (Static for now to show layout) */}
                <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-2xl border border-primary/10 p-6 flex flex-col justify-center items-center text-center">
                    <div className="w-16 h-16 bg-background rounded-full flex items-center justify-center mb-4 shadow-sm text-2xl">
                        🚀
                    </div>
                    <h3 className="text-lg font-semibold text-foreground">Meta Mensal</h3>
                    <p className="text-sm text-muted-foreground mb-6 max-w-[200px]">Mantenha o foco! Você está progredindo bem.</p>

                    <div className="w-full bg-background rounded-full h-3 mb-2 overflow-hidden border border-border/50">
                        <div className="bg-primary h-full rounded-full w-[65%]"></div>
                    </div>
                    <div className="flex justify-between w-full text-xs font-medium text-muted-foreground px-1">
                        <span>0%</span>
                        <span className="text-primary">65%</span>
                        <span>100%</span>
                    </div>
                </div>

            </div>
        </div>
    );
}
